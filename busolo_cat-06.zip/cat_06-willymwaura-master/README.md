[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=10406064&assignment_repo_type=AssignmentRepo)
# Autograding Example: Node
This example project is written in Node, and tested with Jest.

### The assignment
The tests are failing right now because we're not returning the correct string. Fixing this up will make the tests green.

### Setup command
`npm install`

### Run command
`npm test`

### Notes
- 
