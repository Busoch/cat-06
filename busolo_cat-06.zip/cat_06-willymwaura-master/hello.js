function hello() {
  return "Hello world!";
}

module.exports = hello;
